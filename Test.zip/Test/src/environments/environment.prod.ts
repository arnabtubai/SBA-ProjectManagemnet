export const environment = {
  production: true,
  userUrl:'http://172.18.4.141/api/users',
  projectUrl:'http://172.18.4.141/api/projects',
  taskUrl:'http://172.18.4.141/api/tasks'
};
