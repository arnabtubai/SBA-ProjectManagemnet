import { Component, OnInit } from '@angular/core';
import {User} from '../common/user';
import {UserServiceService} from '../user-service.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {

  constructor(private userService: UserServiceService) { }

  public user: User;
  public users:User[];
  public Error:any;
  public buttoncaption:string
  public sortBy:string;
  public term:string;

  ngOnInit() {
    this.buttoncaption = "Add";
    this.userService.getUsers().subscribe(userlist => {
      this.users = userlist;
     })


    this.user = new User();
  
  }
SortById()
{
  this.sortBy = "EmployeeId";

}
SortByFirstName()
{
  this.sortBy = "FirstName";
}
SortByLastName()
{
  this.sortBy = "LastName";
}
  AddUpdateUser(mainForm:NgForm) {

    if(!mainForm.valid)
    {
      return false;
    }

    if(this.buttoncaption == "Add")
    {
      this.userService.Post(this.user).subscribe(response => console.log(response), err => {
        this.Error =err;
        alert(this.Error);

       
      }, () =>{
        alert("Successfully added the user");
        mainForm.resetForm();
        this.Refresh();});
    }
    else{
      this.userService.Put(this.user).subscribe(response => console.log(response), err => {
        this.Error =err;
        alert(this.Error);
     
       
      }, () => {
        alert("Successfully upated the user");
        mainForm.resetForm();
        this.Refresh();});
    }
   
  }
  Refresh()
  {
    this.buttoncaption = "Add"
    this.userService.getUsers().subscribe(userlist => {
      this.users = userlist;
      if(this.user)
      {
       this.user.FirstName= "";
       this.user.LastName= "";
       this.user.EmployeeId="";
      }
       console.log(this.users);
     })
  }

  Reset()
  {

    this.Refresh();
  }
  DeleteUser(User_ID:number)
  {
    if(confirm("Are you sure you want to delete this user? All related tasks will be deleted.."))
    {
    this.userService.Delete(User_ID).subscribe(response => console.log(response), err => {
      this.Error =err;
      alert(this.Error);
    }, () => this.Refresh());
  }
  }

  EditUser(User_ID:number) {
 
   this.userService.getUser(User_ID).subscribe(userlist => {
    this.user = userlist;
   })
   
   window.scrollTo(0, 0);
 
 
    this.buttoncaption = "Update";
    }
    

}
