import { Injectable } from '@angular/core';
import { HttpClient,  HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Task } from './Common/task';
import { catchError, map } from 'rxjs/operators';
import { Observable, throwError as observableThrowError } from 'rxjs';
import { environment } from '../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class TaskService {

  constructor(private http:HttpClient) { }

  public getTasks()
  {
    return this.http.get<Task[]>("http://localhost:51750/Api/Tasks")
    .pipe(map(data => 
      {
        return data;
      }
     
      ), catchError(this.handleError));
  }
  public getTask(TasId:number):Observable<Task>
  {
    return this.getTasks().pipe(
      map(tasks => tasks.find(task => task.Task_ID === TasId))
    );
  }

 public Put(task:Task)
 {
  const httpOptions = {
    headers : new HttpHeaders({
     'Content-Type': 'application/json'
   })
 };

 var body = JSON.stringify(task);
 const url = `${"http://localhost:51750/Api/Tasks"}/${task.Task_ID}`;
  return this.http
    .put(url, body, httpOptions)
    .pipe(catchError(this.handleError));

 }
 // Add New Task
 public Post(task:Task)
 {
   const httpOptions = {
   headers : new HttpHeaders({
    'Content-Type': 'application/json'
  })
};
  var body = JSON.stringify(task);
  
  return this.http
    .post("http://localhost:51750/Api/Tasks", body,httpOptions)
    .pipe(catchError(this.handleError));
 }
  private handleError(res: HttpErrorResponse | any) {
    console.error(res.error || res.body.error);
    return observableThrowError(res.error || 'Server error');
  }
}
