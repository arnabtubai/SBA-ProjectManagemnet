import { User } from "./user";

export class Project {
    Project_ID:number;
    Project:string;
    StartDate:string;
    EndDate:string;
    Priority:number;
    User_ID:number;
    Completed:boolean;
    NumberOfTasks:number
    Users:User
}