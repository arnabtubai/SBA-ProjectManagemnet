import { Component, OnInit } from '@angular/core';
import {Project} from '../common/Projects';
import {ProjectService} from '../project.service';
import {User} from '../common/user';
import {UserServiceService} from '../user-service.service';

import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-projects',
  templateUrl: './projects.component.html',
  styleUrls: ['./projects.component.css']
})
export class ProjectsComponent implements OnInit {

  constructor(private projectService: ProjectService, private userService: UserServiceService) {
    this.project = new Project();
     
   }
   public project: Project;
   public projects:Project[];
   public submitErr:string;
   public buttoncaption:string
   public sortby:string;
   public users: User[];
   public setDate:boolean;
   public selectedUsr:User;
   public managerDetails:string;
   public term:string;
  ngOnInit() {
    this.buttoncaption = "Add";
this.setDate=false;
this.managerDetails="";
this.project = new Project();
this.project.Priority = 0;
this.project.StartDate = new Date().toISOString().substring(0, 10);
var curDate = new Date();
curDate.setDate(curDate.getDate() + 1);
this.project.EndDate = curDate.toISOString().substring(0, 10);

    this.projectService.getProjects().subscribe(projectlist => {
      this.projects = projectlist;
     
     })
  }

  SortByStartDate()
{
  this.sortby = "StartDate";
}
SortByEndDate()
{
  this.sortby = "EndDate";
}
SortByPriority()
{
  this.sortby = "Priority";
}
SortByCompleted()
{
  this.sortby = "Completed";
}
Refresh()
{
 
 this.ngOnInit();
}
AddUpdateProject(mainForm:NgForm) {

  if(!mainForm.valid)
  {
    return false;
  }
  if(this.buttoncaption == "Add")
  {
      this.project.Completed= false;
    
    this.projectService.Post(this.project).subscribe(response => console.log(response), err => {
      this.submitErr =err.ExceptionMessage;
      alert(this.submitErr);
    },() =>{ 
      alert("Successfully added Project");
      this.Refresh();});
  }
  else{
    this.projectService.Put(this.project).subscribe(response => console.log(response), err => {
      this.submitErr =err.ExceptionMessage;
     alert(this.submitErr);
    },() =>{ 
      alert("Successfully updated Project");
      this.Refresh();});
  }
 
}
Reset(mainForm:NgForm)
{
  //mainForm.resetForm();
  this.Refresh();
}

EditProject(ProjectId:number) {

  this.buttoncaption="Update";
  this.projectService.getProject(ProjectId).subscribe(prj => {
         
    this.project = prj;
   
  
  },err=>alert(err),()=>{

  this.userService.getUser(this.project.User_ID).subscribe(userlist => {
  
    this.managerDetails = userlist.EmployeeId.toString() + " - " + userlist.FirstName + " " + userlist.LastName;

  });

  });
  window.scrollTo(0, 0);
}
  SearchUser(){
    
    this.userService.getUsers().subscribe(userlist => {
      this.users = userlist;

     })
     return false;
  }
  ListClick(event, newUsr){
    this.selectedUsr=newUsr;
  }
  SelectUser(){
   
    this.project.User_ID = this.selectedUsr.User_ID;

    this.managerDetails = this.selectedUsr.EmployeeId.toString() + " - "+ this.selectedUsr.FirstName + " " + this.selectedUsr.LastName;

  }
  SuspendProject(Project_ID:number)
  {
    if(confirm("Are you sure you want to delete this project? Related tasks will be deleted"))
    {
 
    this.projectService.Delete(Project_ID).subscribe(response => console.log(response), err => {
      this.submitErr =err.ExceptionMessage;
      alert(this.submitErr);
    },() => this.Refresh());
  }

  }


}
