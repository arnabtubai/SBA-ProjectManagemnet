import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProjectsComponent } from './projects/projects.component';
import { TasksComponent } from './tasks/tasks.component';
import { UsersComponent } from './users/users.component';
import { CommonModule } from '@angular/common';
import { ViewTaskComponent } from './view-task/view-task.component';

const routes: Routes = [
  {path: 'project', component: ProjectsComponent  },
  {path: 'task', component: TasksComponent  },
  {path: 'task/:id', component: TasksComponent  },
  {path: 'User', component: UsersComponent},
  {path: 'ViewTask', component: ViewTaskComponent  }
 
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
