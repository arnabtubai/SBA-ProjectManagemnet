import { Injectable } from '@angular/core';
import { User } from './Common/user';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { catchError, map } from 'rxjs/operators';
import { Observable, throwError as observableThrowError } from 'rxjs';
import { environment } from '../environments/environment';
@Injectable({
  providedIn: 'root'
})
export class UserServiceService {

  constructor(private http: HttpClient) { }
  public getUsers() {

    return this.http.get<User[]>(environment.url+"/api/Users")
      .pipe(map(data => {
        return data;
      }

      ), catchError(this.handleError));
  }
  public getUser(User_Id: number): Observable<User> {
    return this.http.get<User>(environment.url + "/api/Users/" + User_Id.toString())
      .pipe(map(data => {
        return data;
      }

      ), catchError(this.handleError));
  }

  public Put(user: User) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };

    var body = JSON.stringify(user);

    const url = environment.url+"/api/Users/"+user.User_ID;

    return this.http
      .put(url, body, httpOptions)
      .pipe(catchError(this.handleError));

  }
  // delete user
  public Delete(User_ID: number) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };

    const url = environment.url+"/api/Users/"+User_ID;
    return this.http
      .delete(url, httpOptions)
      .pipe(catchError(this.handleError));

  }
  // Add New User
  public Post(user: User) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
    var body = JSON.stringify(user);

    return this.http
      .post(environment.url+"/api/Users", body, httpOptions)
      .pipe(catchError(this.handleError));

  }



  private handleError(res: HttpErrorResponse | any) {
    return observableThrowError(res.error || 'Server error');
  }
}
