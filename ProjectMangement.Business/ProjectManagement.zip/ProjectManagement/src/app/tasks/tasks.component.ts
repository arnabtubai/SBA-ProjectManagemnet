import { Task } from "../common/Task"
import { User } from "../common/user"
import { Project } from "../common/Projects"
import { Component, EventEmitter, Input, OnInit, Output, ViewChild, ElementRef, Directive } from '@angular/core';

import { ActivatedRoute, Params, Router } from "@angular/router";
import { TaskService } from '../task.service';
import { Route } from "../../../node_modules/@angular/compiler/src/core";
import { DatePipe } from '@angular/common';
import { UserServiceService } from '../user-service.service';
import { ProjectService } from '../project.service'


import { asLiteral } from "@angular/compiler/src/render3/view/util";
import { $ } from "protractor";
import { NG_VALIDATORS, FormGroup, FormBuilder, Validators, NgForm } from "@angular/forms";


@Component({
  selector: 'app-tasks',
  templateUrl: './tasks.component.html',
  styleUrls: ['./tasks.component.css']
})
export class TasksComponent implements OnInit {

  @Input() task: Task;
  @Output() close = new EventEmitter();
  Error: any;
  navigated = false; // true if navigated here
  buttonCaption: string;
  public submitErr: string;
  public id: string;
public rang:number;
  public errors: any = { isError: false, errorMessage: '' };
  myForm: any;


  AddUpdate(TaskForm: NgForm) {

    if (!TaskForm.valid) {


      return;
    }
    if (this.buttonCaption != "Add") {

      this.task.Status = "N"
      this.taskService.Put(this.task).subscribe(response => console.log(response), error => {
        this.Error = error.Message.replace("\n", "<br>");
        alert("Error Occured:\n" + error.Message)
      }, () => {
        alert("Successfully Updated Task");
        this.Error = "";
        const url = '/ViewTask';
        this.router.navigate([url]);
      });

    }
    else {
      this.task.Status = "N"
      this.taskService.Post(this.task).subscribe(response => console.log(response), error => {
        this.Error = error.Message.replace("\n", "<br>");
        alert("Error Occured:\n" + error.Message);
      }, () => {
        alert("Successfully Added Task");
        this.Error = "";
        this.Cancel()
      });
    }
  }

  Cancel() {
    this.Error = "";
    if (this.buttonCaption != "Add") {
      const url = '/ViewTask';
      this.router.navigate([url]);
    }
    else {

      this.navigated = false;
      this.buttonCaption = "Add";
      this.task = new Task();
      this.task.Priority = 0;
      this.task.StartDate = new Date().toISOString().substring(0, 10);
      var curDate = new Date();
      this.userDetails = "";
      this.parentDetails = "";
      this.projectDetails = "";
      curDate.setDate(curDate.getDate() + 1);
      this.task.EndDate = curDate.toISOString().substring(0, 10);
      this.task.IsParentTask = true;
    }

  }
  constructor(private taskService: TaskService, private projectService: ProjectService, private userService: UserServiceService,
    private route: ActivatedRoute, private router: Router) {
    this.task = new Task();
    this.route.params.subscribe(params => { this.id = params['id']; });
  }

  ngOnInit(): void {

    if (this.id !== undefined) {


      this.navigated = true;
      this.buttonCaption = "Update";
      this.taskService.getTask(parseInt(this.id)).subscribe(task => {

        this.task = task;
        this.Error = "";

      }, error => {
        this.Error = error.Message.replace("\n", "<br>");
        alert("Error Occured:\n" + error.Message);
      },
        () => {
          this.Error = "";
          this.projectService.getProject(this.task.Project_ID).subscribe(projectlist => {
            this.projectDetails = projectlist.Project_ID.toString() + " - " + projectlist.Project;
          }, error => {
            this.Error = error.Message.replace("\n", "<br>");
            alert("Error Occured:\n" + error.Message);
          });

          this.userService.getUser(this.task.User_ID).subscribe(userlist => {

            this.userDetails = userlist.EmployeeId.toString() + " - " + userlist.FirstName + " " + userlist.LastName;

          }, error => {
            this.Error = error.Message.replace("\n", "<br>");
            alert("Error Occured:\n" + error.Message);
          });
          if (this.task.Parent_ID > 0) {
            
            this.parentDetails = this.task.Parent_ID.toString() + " - " + this.task.ParentTask;
            this.task.IsParentTask = true;
          }
          else{
            this.parentDetails = "";
            this.task.IsParentTask = false;
          }
        })


    } else {

      this.navigated = false;
      this.buttonCaption = "Add";
      this.task = new Task();
      this.task.Priority = 0;
      this.task.StartDate = new Date().toISOString().substring(0, 10);
      var curDate = new Date();
      curDate.setDate(curDate.getDate() + 1);
      this.task.EndDate = curDate.toISOString().substring(0, 10);
      this.task.IsParentTask = true;
    }


  }

  // Variables for selection
  users: User[];
  projects: Project[];
  parents: Task[];
  selectedUsr: User;
  selectedPar: Task;
  selectedPjt: Project;
  projectDetails: string;
  parentDetails: string;
  userDetails: string;


  // end variables for selection

  SearchProject() {

    this.projectService.getProjects().subscribe(projectlist => {
      this.projects = projectlist;


    })
  }


  ChangeParent() {

    if (this.task.IsParentTask) {
      this.parentDetails = "";
      this.task.Parent_ID = 0;


    }
  }
  ClickPjt(event, newPjt) {
    this.selectedPjt = newPjt;
  }
  SelectProject() {

    this.task.Project_ID = this.selectedPjt.Project_ID;
    this.projectDetails = this.selectedPjt.Project_ID.toString() + " - " + this.selectedPjt.Project;

  }


  SearchParent() {

    this.taskService.getTasks().subscribe(task => {
      if (this.buttonCaption != "Add") {
        this.parents = task.filter(x => x.Task_ID != this.task.Task_ID);
      }
      else {
        this.parents = task;
      }
    }, err => console.log(err)
    );

  }
  ClickPar(event, newPar) {
    this.selectedPar = newPar;
  }
  SelectParent() {

    this.task.Parent_ID = this.selectedPar.Task_ID
    this.parentDetails = this.selectedPar.Task_ID.toString() + " - " + this.selectedPar.Task;
  }
  SearchUser() {

    this.userService.getUsers().subscribe(userlist => {
      this.users = userlist;

    }, err => console.log(err))
  }
  ClickUsr(event, newUsr) {
    this.selectedUsr = newUsr;
  }
  SelectUser() {

    this.task.User_ID = this.selectedUsr.User_ID;
    this.userDetails = this.selectedUsr.EmployeeId.toString() + " - " + this.selectedUsr.FirstName + " " + this.selectedUsr.LastName;

  }

}
