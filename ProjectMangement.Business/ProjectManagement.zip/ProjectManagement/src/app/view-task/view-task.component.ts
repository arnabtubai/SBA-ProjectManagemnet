import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import {DatePipe} from '@angular/common';

import {Task} from '../common/task';
import {TaskService} from '../task.service';

@Component({
  selector: 'app-view-task',
  templateUrl: './view-task.component.html',
  styleUrls: ['./view-task.component.css']
})
export class ViewTaskComponent implements OnInit {

  constructor(private dal:TaskService , private router: Router) { }
  public tasks:Task[];
  public sortBy:string;
  public term:string;
  public sortby : string;
  ngOnInit() {
    this.dal.getTasks().subscribe(task => {
      this.tasks = task;
     }
     );
  }
  public EditTask(TaskId:number):void{
    const link = '/task/'+ TaskId;
    this.router.navigate([link]);
  }
  SortByStartDate()
  {
    this.sortby = "StartDate Desc";
  }
  SortByEndDate()
  {
    this.sortby = "EndDate";
  }
  SortByPriority()
  {

    this.sortby = "Priority";
  }
  SortByCompleted()
  {
    this.sortby = "Completed";
  }
  public EndTask(task:Task):void{

    if(confirm("Are you sure that you want to completet this task?"))
    {
      task.Status = "Completed";
      this.dal.Put(task).subscribe(response => console.log(response), err => alert(err),()=>{
        this.dal.getTasks().subscribe(task => {
          this.tasks = task;
         }
         );
      });
    }
  
  
  }
}
