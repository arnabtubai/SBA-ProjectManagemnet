export class Task {
    Task_ID:number;
    Project_ID:number;
    Task:string;
    IsParentTask:boolean;
    Priority:number;
    Parent_ID:number;
    StartDate:string;
    EndDate:string;
    User_ID:number;
    Status:string;
    ParentTask:string;
}