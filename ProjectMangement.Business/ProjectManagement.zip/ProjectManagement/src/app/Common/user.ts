export class User {
    User_ID:number;
    EmployeeId:string;
    FirstName:string;
    LastName:string;
}